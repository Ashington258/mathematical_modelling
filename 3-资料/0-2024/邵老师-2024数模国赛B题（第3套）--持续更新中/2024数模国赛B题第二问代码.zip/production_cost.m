
% 函数定义
function total_cost = production_cost(N, a11, a12, a13, a21, a22, a31, a32, a33, c1, c2, c3, c4, detect_part1, detect_part2, detect_final, disassemble)

    % 零件1、2的合格率
    part_quality_rate1 = 1 - a11 * (1 - detect_part1);
    part_quality_rate2 = 1 - a12 * (1 - detect_part2);

    % 成品的合格率
    product_quality_rate = part_quality_rate1 * part_quality_rate2 * (1 - a13 * (1 - detect_final));

    % 零件1、2的采购成本
    part_purchase_cost1 = N / part_quality_rate1 * a21;
    part_purchase_cost2 = N / part_quality_rate2 * a22;

    % 零件1、2的检测成本
    part_testing_cost1 = detect_part1 * N * a31;
    part_testing_cost2 = detect_part2 * N * a32;

    % 成品的装配成本
    assembly_cost = N * c4;

    % 成品的检测成本
    final_testing_cost = detect_final * N * a33;

    % 不合格品的调换成本
    replacement_cost = (1 - detect_final) * N * (1 - product_quality_rate) * c2;

    % 不合格成品的拆解成本和回收收益
    scrap_cost = disassemble * N * (1 - product_quality_rate) * c3;
    scrap_revenue = disassemble * N * (1 - product_quality_rate) * 0.6 * c1;

    % 总成本计算
    total_cost = part_purchase_cost1 + part_purchase_cost2 + ...
                 part_testing_cost1 + part_testing_cost2 + ...
                 assembly_cost + final_testing_cost + ...
                 replacement_cost + scrap_cost - scrap_revenue;
end