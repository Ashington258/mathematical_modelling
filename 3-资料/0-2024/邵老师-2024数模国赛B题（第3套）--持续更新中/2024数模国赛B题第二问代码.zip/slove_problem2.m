clc, clear
N = 1000; % 生产的产品数量
a11 = [0.1, 0.2, 0.1, 0.2, 0.1, 0.05]; % 零配件1次品率
a21 = [4, 4, 4, 4, 4, 4]; % 零配件1单价
a31 = [2, 2, 2, 1, 8, 2]; % 零配件1检测成本
a12 = [0.1, 0.2, 0.1, 0.2, 0.2, 0.05]; % 零配件2次品率
a22 = [18, 18, 18, 18, 18, 18]; % 零配件2单价
a32 = [3, 3, 3, 1, 1, 3]; % 零配件2检测成本
a13 = [0.1, 0.2, 0.1, 0.2, 0.1, 0.05]; % 成品次品率
c4 = [6, 6, 6, 6, 6, 6]; % 成品装配成本
a33 = [3, 3, 3, 2, 2, 3]; % 成品检测成本
c1 = [56, 56, 56, 56, 56, 56]; % 成品市场售价
c2 = [6, 6, 30, 30, 10, 10]; % 不合格品调换损失
c3 = [5, 5, 5, 5, 5, 40]; % 拆解费用

data = zeros(6, 17); % 用于存储总成本和最优方案编号
optimal_costs = zeros(6, 1); % 用于存储每种情况下的最小总成本

for i = 1:6
    number = 1;
    minlable = 0;
    minvalue = Inf;
    
    % 决策变量
    for detect_part1 = 1:2 % 是否检测零配件1
        for detect_part2 = 1:2 % 是否检测零配件2
            for detect_final = 1:2 % 是否检测成品
                for disassemble = 1:2 % 是否拆解不合格成品
                    % 计算总成本
                    total_cost = production_cost(N, a11(i), a12(i), a13(i), a21(i), a22(i), a31(i), a32(i), a33(i), c1(i), c2(i), c3(i), c4(i), detect_part1 - 1, detect_part2 - 1, detect_final - 1, disassemble - 1);
                    data(i, number) = total_cost;
                    
                    % 找出最小成本
                    if total_cost < minvalue
                        minlable = number;
                        minvalue = total_cost;
                    end
                    
                    number = number + 1;
                end
            end
        end
    end
    
    % 存储最优方案编号和最小成本
    data(i, 17) = minlable;
    optimal_costs(i) = minvalue; % 记录最小总成本
end

data1 = data';

% 可视化每种情况下的最优方案总成本
figure;
bar(optimal_costs);
title('每种情况下的最优总成本');
xlabel('情景编号');
ylabel('最小总成本');
xticks(1:6);
grid on;
figure;
% 可视化每种情况下的所有方案成本对比
hold on;
colors = lines(6); % 生成不同颜色
for i = 1:6
    plot(1:16, data(i, 1:16), 'o-', 'Color', colors(i,:), 'DisplayName', sprintf('情景 %d', i));
end
title('不同情景下各方案总成本对比');
xlabel('方案编号');
ylabel('总成本');
legend('show');
grid on;
hold off;